import { Button } from '@/components/ui/button'
import React from 'react'

const HomePage = () => {
  return (
    <div><Button> Button for test</Button></div>
  )
}

export default HomePage